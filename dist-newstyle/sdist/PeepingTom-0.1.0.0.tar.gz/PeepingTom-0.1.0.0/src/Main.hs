module Main where

import PeepingTom

main :: IO ()
main = do
    PeepingTom.debug
    return ()
