module PeepingTom.Internal where

type PID = Int
type FD = Int
type Address = Int
type Size = Int
